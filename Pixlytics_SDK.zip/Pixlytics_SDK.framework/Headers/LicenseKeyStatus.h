//
//  LicenseKeyStatus.h
//  Pixlytics-SDK
//
//  Created by Bertrand VILLAIN on 01/04/2019.
//  Copyright © 2019 Wassa. All rights reserved.
//

#ifndef LICENSEKEYSTATUS_h
#define LICENSEKEYSTATUS_h

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, LicenseKeyStatus) {
  LicenseOk,
  InvalidLicenseFormat,
  InvalidLicenseModified,
  InvalidLicenseExpired,
  InvalidLicenseNotPaid,
  InvalidLicenseBlocked,
  LicenseUnknownError
};

NS_ASSUME_NONNULL_END

#endif
